import './App.css'
import Game from './components/Game'
// import './assets/buff.png'

const App = () => {
  return (
    <div>
      <Game />
    </div>
  )
}

export default App
